import React from 'react';
import { CLINIC_INFO, CLINIC_STATS } from '../data/clinicData';
import { motion } from 'motion/react';
import { Award, Heart, ShieldCheck, Sparkles, CheckCircle2, Stethoscope, Microscope, UserCheck } from 'lucide-react';

export const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-20 lg:py-28 bg-white relative overflow-hidden">
      {/* Background Subtle Gradient Accents */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-72 h-72 bg-sky-100/50 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-teal-100/40 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-bold uppercase tracking-wider">
            <Stethoscope className="w-3.5 h-3.5 text-sky-600" />
            <span>Dedicated Dental Care</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Meet <span className="bg-gradient-to-r from-sky-600 to-teal-600 bg-clip-text text-transparent">Dr. Richa</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            A compassionate approach to dentistry, combining art, modern technology, and clinical excellence for life-changing smiles.
          </p>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Doctor Modern Card Photo */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-5 relative"
          >
            <div className="relative rounded-3xl bg-gradient-to-br from-sky-50 via-teal-50/50 to-white p-4 border border-sky-100 shadow-xl shadow-sky-500/10">
              
              {/* Doctor Portrait Image */}
              <div className="rounded-2xl overflow-hidden aspect-[3/4] relative bg-slate-100">
                <img
                  src={CLINIC_INFO.doctorImageUrl}
                  alt="Dr. Richa Dental Surgeon"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-slate-950/20 to-transparent" />

                {/* Overlaid Badges */}
                <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl bg-white/90 backdrop-blur-md border border-white/80 shadow-md">
                  <p className="text-xs font-bold uppercase tracking-wide text-sky-600">BDS • Cosmetic & Implant Specialist</p>
                  <h3 className="text-lg font-black text-slate-900">{CLINIC_INFO.doctorName}</h3>
                  <p className="text-xs text-slate-600 mt-0.5">Founder & Lead Dental Surgeon</p>
                </div>
              </div>

              {/* Decorative Corner Badge */}
              <div className="absolute -top-5 -right-5 bg-gradient-to-br from-sky-600 to-teal-600 text-white rounded-2xl p-4 shadow-lg flex items-center gap-3">
                <Award className="w-8 h-8 text-sky-200 shrink-0" />
                <div>
                  <p className="text-xl font-black leading-none">10+</p>
                  <p className="text-[10px] font-semibold tracking-wider uppercase text-sky-100 mt-1">Years Experience</p>
                </div>
              </div>

            </div>
          </motion.div>

          {/* Right Column: Short Professional Story & Core Values */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-7 space-y-6 text-left"
          >
            <div className="space-y-4">
              <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-snug">
                Gentle, Modern & Patient-Centered Dentistry
              </h3>
              
              <p className="text-slate-600 text-base leading-relaxed">
                With over a decade of hands-on clinical experience, <strong className="text-slate-900 font-semibold">Dr. Richa</strong> has established a reputation for delivering seamless, pain-free dental care. She completed her BDS with top honors and has pursued advanced fellowship training in Aesthetic Dentistry and Dental Implantology.
              </p>

              <p className="text-slate-600 text-base leading-relaxed">
                Her clinic philosophy centers on total patient comfort, transparent communication, and meticulous precision. From nervous children to adults requiring full smile reconstructions, Dr. Richa treats every patient like family with gentle care and state-of-the-art equipment.
              </p>
            </div>

            {/* 4 Feature Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 hover:border-sky-200 transition-colors flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center shrink-0">
                  <Microscope className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Advanced 3D Technology</h4>
                  <p className="text-xs text-slate-500 mt-0.5">3D intraoral optical scanners & digital smile mapping.</p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 hover:border-teal-200 transition-colors flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-600 flex items-center justify-center shrink-0">
                  <Heart className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Gentle & Painless</h4>
                  <p className="text-xs text-slate-500 mt-0.5">Anxiety-free local anesthesia & delicate techniques.</p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 hover:border-sky-200 transition-colors flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">100% Hospital Grade Sterilisation</h4>
                  <p className="text-xs text-slate-500 mt-0.5">Class-B autoclave steam sterilization standards.</p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 hover:border-teal-200 transition-colors flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-600 flex items-center justify-center shrink-0">
                  <UserCheck className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">Affordable & Transparent</h4>
                  <p className="text-xs text-slate-500 mt-0.5">Upfront cost quotes with flexible payment plans.</p>
                </div>
              </div>
            </div>

            {/* Quote / Doctor Signature snippet */}
            <div className="p-5 rounded-2xl bg-gradient-to-r from-sky-500 to-teal-600 text-white shadow-md flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm font-medium italic opacity-95">
                  "Every healthy smile begins with trust, gentle care, and zero fear. We are honored to care for your teeth."
                </p>
                <p className="text-xs font-bold uppercase tracking-wider text-teal-100 mt-2">— Dr. Richa, BDS</p>
              </div>
            </div>

          </motion.div>

        </div>
      </div>
    </section>
  );
};
