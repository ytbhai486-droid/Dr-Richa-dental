import React, { useState } from 'react';
import { SERVICES } from '../data/clinicData';
import { Service } from '../types';
import { ServiceModal } from './ServiceModal';
import { motion } from 'motion/react';
import {
  Sparkles,
  Zap,
  ShieldCheck,
  Activity,
  Grid,
  XCircle,
  Smile,
  Heart,
  Crown,
  PhoneCall,
  Clock,
  ArrowRight,
  Stethoscope
} from 'lucide-react';

interface ServicesSectionProps {
  onBookTreatment: (serviceTitle: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onBookTreatment }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedService, setSelectedService] = useState<Service | null>(null);

  const categories = [
    { id: 'all', label: 'All Services' },
    { id: 'preventive', label: 'Preventive Care' },
    { id: 'cosmetic', label: 'Cosmetic & Smile' },
    { id: 'restorative', label: 'Restorative & Implants' },
    { id: 'orthodontics', label: 'Aligners & Braces' },
    { id: 'surgical', label: 'Surgical & Emergency' },
  ];

  const filteredServices = activeCategory === 'all'
    ? SERVICES
    : SERVICES.filter((s) => s.category === activeCategory);

  // Helper icon selector
  const renderServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Sparkles':
        return <Sparkles className="w-6 h-6 text-sky-600" />;
      case 'Zap':
        return <Zap className="w-6 h-6 text-amber-500" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-6 h-6 text-teal-600" />;
      case 'Activity':
        return <Activity className="w-6 h-6 text-rose-500" />;
      case 'Grid':
        return <Grid className="w-6 h-6 text-sky-600" />;
      case 'XCircle':
        return <XCircle className="w-6 h-6 text-slate-700" />;
      case 'Smile':
        return <Smile className="w-6 h-6 text-teal-600" />;
      case 'Heart':
        return <Heart className="w-6 h-6 text-pink-500" />;
      case 'Crown':
        return <Crown className="w-6 h-6 text-amber-600" />;
      case 'PhoneCall':
        return <PhoneCall className="w-6 h-6 text-red-600" />;
      default:
        return <Stethoscope className="w-6 h-6 text-sky-600" />;
    }
  };

  return (
    <section id="services" className="py-20 lg:py-28 bg-slate-50/70 relative overflow-hidden">
      {/* Decorative Glow */}
      <div className="absolute top-1/3 right-0 w-80 h-80 bg-sky-200/40 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-teal-200/30 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-sky-600" />
            <span>Comprehensive Dental Solutions</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Our Dental <span className="bg-gradient-to-r from-sky-600 to-teal-600 bg-clip-text text-transparent">Services</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            From routine teeth cleaning to advanced 3D implants & Hollywood smile transformations.
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeCategory === cat.id
                  ? 'bg-gradient-to-r from-sky-600 to-teal-600 text-white shadow-md shadow-sky-500/20 scale-105'
                  : 'bg-white text-slate-600 hover:bg-sky-50 hover:text-sky-600 border border-slate-200/80'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Services 3D Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {filteredServices.map((service, index) => (
            <motion.div
              key={service.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
              className="group relative bg-white/80 backdrop-blur-md rounded-3xl border border-sky-100/80 p-6 shadow-md hover:shadow-xl hover:shadow-sky-500/10 hover:-translate-y-1.5 transition-all duration-300 flex flex-col justify-between"
            >
              <div className="space-y-4 text-left">
                {/* Top Icon & Category Tag */}
                <div className="flex items-center justify-between">
                  <div className="w-14 h-14 rounded-2xl bg-sky-50 group-hover:bg-sky-100 border border-sky-100 flex items-center justify-center shadow-sm transition-colors group-hover:scale-110 duration-300">
                    {renderServiceIcon(service.iconName)}
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-slate-100 text-slate-600 text-[10px] font-bold uppercase tracking-wide">
                    {service.category}
                  </span>
                </div>

                {/* Service Title & Short Description */}
                <div>
                  <h3 className="text-xl font-bold text-slate-900 group-hover:text-sky-600 transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed line-clamp-3">
                    {service.shortDesc}
                  </p>
                </div>

                {/* Duration Tag */}
                <div className="flex items-center gap-1.5 text-xs text-slate-500 pt-1 font-medium">
                  <Clock className="w-3.5 h-3.5 text-sky-500" />
                  <span>Duration: {service.duration}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-6 mt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                <button
                  onClick={() => setSelectedService(service)}
                  className="text-xs font-bold text-sky-600 hover:text-sky-700 flex items-center gap-1 group-hover:translate-x-1 transition-transform"
                >
                  <span>Learn More</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => onBookTreatment(service.title)}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-semibold text-teal-800 bg-teal-50 hover:bg-teal-100 border border-teal-200 transition-colors"
                >
                  Book Now
                </button>
              </div>
            </motion.div>
          ))}
        </div>

      </div>

      {/* Service Modal */}
      <ServiceModal
        service={selectedService}
        onClose={() => setSelectedService(null)}
        onBookTreatment={onBookTreatment}
      />
    </section>
  );
};
