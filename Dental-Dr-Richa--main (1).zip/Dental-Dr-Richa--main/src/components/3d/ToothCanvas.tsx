import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';

interface ToothCanvasProps {
  className?: string;
  interactive?: boolean;
}

export const ToothCanvas: React.FC<ToothCanvasProps> = ({ className = '', interactive = true }) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [activeModel, setActiveModel] = useState<'tooth' | 'mirror' | 'implant'>('tooth');
  const isHoveredRef = useRef(false);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    const width = container.clientWidth || 400;
    const height = container.clientHeight || 400;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0, 8);

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: 'high-performance',
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Clean container before appending
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Group holding the 3D Tooth Model
    const toothGroup = new THREE.Group();
    scene.add(toothGroup);

    // --- MATERIALS ---
    // Enamel glossy white tooth material with sky-blue specular reflection
    const enamelMaterial = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#f8fafc'),
      emissive: new THREE.Color('#38bdf8'),
      emissiveIntensity: 0.05,
      roughness: 0.15,
      metalness: 0.05,
      clearcoat: 1.0,
      clearcoatRoughness: 0.08,
      transmission: 0.1,
      ior: 1.5,
      reflectivity: 0.9,
    });

    const rootMaterial = new THREE.MeshPhysicalMaterial({
      color: new THREE.Color('#f1f5f9'),
      roughness: 0.35,
      metalness: 0.02,
      clearcoat: 0.3,
    });

    const titaniumMaterial = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#94a3b8'),
      metalness: 0.85,
      roughness: 0.2,
    });

    const tealGlowMaterial = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#0d9488'),
      emissive: new THREE.Color('#14b8a6'),
      emissiveIntensity: 0.4,
      roughness: 0.3,
    });

    // --- PROCEDURAL 3D TOOTH GEOMETRY ---
    // Crown top
    const crownGeo = new THREE.CylinderGeometry(1.4, 1.1, 1.3, 32, 16);
    // Smooth cusps by adding rounded top bumps
    const crownMesh = new THREE.Mesh(crownGeo, enamelMaterial);
    crownMesh.position.y = 0.6;
    crownMesh.castShadow = true;
    crownMesh.receiveShadow = true;
    toothGroup.add(crownMesh);

    // Cusp Bumps (4 anatomical bumps on top of molar)
    const cuspGeo = new THREE.SphereGeometry(0.55, 16, 16);
    cuspGeo.scale(1, 0.6, 1);

    const cuspPositions = [
      [-0.5, 1.25, -0.5],
      [0.5, 1.25, -0.5],
      [-0.5, 1.25, 0.5],
      [0.5, 1.25, 0.5],
    ];

    cuspPositions.forEach(([x, y, z]) => {
      const cusp = new THREE.Mesh(cuspGeo, enamelMaterial);
      cusp.position.set(x, y, z);
      cusp.castShadow = true;
      toothGroup.add(cusp);
    });

    // Tooth Neck / Cervix
    const neckGeo = new THREE.CylinderGeometry(1.1, 0.95, 0.5, 24);
    const neckMesh = new THREE.Mesh(neckGeo, enamelMaterial);
    neckMesh.position.y = -0.2;
    toothGroup.add(neckMesh);

    // Molar Roots (2 tapering roots)
    const rootGeo1 = new THREE.ConeGeometry(0.48, 1.8, 20);
    rootGeo1.rotateX(Math.PI);

    const rootMesh1 = new THREE.Mesh(rootGeo1, rootMaterial);
    rootMesh1.position.set(-0.4, -1.2, 0);
    rootMesh1.rotation.z = -0.12;
    rootMesh1.castShadow = true;
    toothGroup.add(rootMesh1);

    const rootMesh2 = new THREE.Mesh(rootGeo1, rootMaterial);
    rootMesh2.position.set(0.4, -1.2, 0);
    rootMesh2.rotation.z = 0.12;
    rootMesh2.castShadow = true;
    toothGroup.add(rootMesh2);

    // Futuristic Dental Implant Base Ring (Glowing Teal Accent Ring)
    const ringGeo = new THREE.TorusGeometry(1.18, 0.08, 16, 48);
    ringGeo.rotateX(Math.PI / 2);
    const ringMesh = new THREE.Mesh(ringGeo, tealGlowMaterial);
    ringMesh.position.y = 0.0;
    toothGroup.add(ringMesh);

    // Titanium Root Implant Threads (Subtle futuristic detail)
    const implantScrewGeo = new THREE.CylinderGeometry(0.35, 0.25, 1.2, 16);
    const implantScrew = new THREE.Mesh(implantScrewGeo, titaniumMaterial);
    implantScrew.position.set(0, -1.0, 0);
    toothGroup.add(implantScrew);

    // --- ORBITING SPARKLE PARTICLES ---
    const particleCount = 45;
    const particleGeo = new THREE.BufferGeometry();
    const particlePos = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      particlePos[i] = (Math.random() - 0.5) * 6;
      particlePos[i + 1] = (Math.random() - 0.5) * 6;
      particlePos[i + 2] = (Math.random() - 0.5) * 6;
    }

    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePos, 3));

    const particleMaterial = new THREE.PointsMaterial({
      color: new THREE.Color('#38bdf8'),
      size: 0.08,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending,
    });

    const particles = new THREE.Points(particleGeo, particleMaterial);
    scene.add(particles);

    // --- LIGHTING ---
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambientLight);

    // Key Light (Sky Blue tone)
    const keyLight = new THREE.DirectionalLight(0x38bdf8, 2.5);
    keyLight.position.set(5, 8, 5);
    keyLight.castShadow = true;
    scene.add(keyLight);

    // Fill Light (Teal tone)
    const fillLight = new THREE.DirectionalLight(0x14b8a6, 1.8);
    fillLight.position.set(-5, -3, -2);
    scene.add(fillLight);

    // Rim / Back light for sparkling glossy outline
    const rimLight = new THREE.PointLight(0xffffff, 3, 20);
    rimLight.position.set(0, 4, -5);
    scene.add(rimLight);

    // --- MOUSE / TOUCH INTERACTION ---
    let mouseX = 0;
    let mouseY = 0;
    let targetRotationX = 0;
    let targetRotationY = 0;

    const handleMouseMove = (event: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((event.clientY - rect.top) / rect.height) * 2 - 1);

      mouseX = x * 0.8;
      mouseY = y * 0.6;
    };

    if (interactive) {
      window.addEventListener('mousemove', handleMouseMove);
    }

    // --- ANIMATION LOOP ---
    let animationFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Smooth floating motion
      toothGroup.position.y = Math.sin(elapsedTime * 1.5) * 0.18;

      // Mouse tracking interpolation
      targetRotationY += (mouseX - targetRotationY) * 0.05;
      targetRotationX += (mouseY - targetRotationX) * 0.05;

      // Base auto-rotation + mouse response
      toothGroup.rotation.y = elapsedTime * 0.4 + targetRotationY;
      toothGroup.rotation.x = Math.sin(elapsedTime * 0.8) * 0.1 + targetRotationX;

      // Orbit particles
      particles.rotation.y = elapsedTime * 0.15;
      particles.rotation.x = Math.cos(elapsedTime * 0.1) * 0.1;

      // Pulse ring emissive intensity
      tealGlowMaterial.emissiveIntensity = 0.3 + Math.sin(elapsedTime * 3) * 0.2;

      renderer.render(scene, camera);
    };

    animate();

    // --- RESIZE HANDLER ---
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      if (w > 0 && h > 0) {
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      }
    };

    const resizeObserver = new ResizeObserver(() => handleResize());
    resizeObserver.observe(container);

    // Clean up
    return () => {
      cancelAnimationFrame(animationFrameId);
      resizeObserver.disconnect();
      if (interactive) {
        window.removeEventListener('mousemove', handleMouseMove);
      }
      scene.clear();
      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [interactive]);

  return (
    <div
      className={`relative w-full h-full min-h-[320px] md:min-h-[420px] flex items-center justify-center ${className}`}
      onMouseEnter={() => (isHoveredRef.current = true)}
      onMouseLeave={() => (isHoveredRef.current = false)}
    >
      <div ref={mountRef} className="w-full h-full absolute inset-0 cursor-grab active:cursor-grabbing" />
      
      {/* Subtle background radial glow */}
      <div className="absolute inset-0 pointer-events-none bg-gradient-to-tr from-sky-400/20 via-teal-300/10 to-transparent blur-3xl rounded-full scale-75 animate-pulse" />

      {/* Floating 3D Badge Label */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 px-4 py-1.5 rounded-full bg-white/80 backdrop-blur-md border border-sky-200/80 shadow-lg text-xs font-semibold text-slate-700 flex items-center gap-2 pointer-events-none z-10 animate-bounce">
        <span className="w-2 h-2 rounded-full bg-teal-500 animate-ping" />
        <span>Interactive 3D Tooth Model • Drag to Rotate</span>
      </div>
    </div>
  );
};
