import React, { useState } from 'react';
import { GALLERY_ITEMS } from '../data/clinicData';
import { GalleryItem } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Image as ImageIcon, Sparkles, X, Maximize2, Sliders } from 'lucide-react';

export const GallerySection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeModalItem, setActiveModalItem] = useState<GalleryItem | null>(null);
  const [sliderPos, setSliderPos] = useState<number>(50); // Before/After slider %

  const categories = [
    { id: 'all', label: 'All Photos' },
    { id: 'transformations', label: 'Smile Transformations' },
    { id: 'interior', label: 'Clinic Interior' },
    { id: 'equipment', label: 'Modern Equipment' },
    { id: 'care', label: 'Patient Care' },
  ];

  const filteredItems = activeCategory === 'all'
    ? GALLERY_ITEMS
    : GALLERY_ITEMS.filter((g) => g.category === activeCategory);

  return (
    <section id="gallery" className="py-20 lg:py-28 bg-white relative overflow-hidden">
      {/* Background Accent */}
      <div className="absolute top-10 right-10 w-96 h-96 bg-sky-100/40 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-bold uppercase tracking-wider">
            <ImageIcon className="w-3.5 h-3.5 text-sky-600" />
            <span>Clinic Showcase</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Clinic <span className="bg-gradient-to-r from-sky-600 to-teal-600 bg-clip-text text-transparent">Gallery</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Explore our state-of-the-art clinic facilities, 3D equipment, and breathtaking real smile transformations.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                activeCategory === cat.id
                  ? 'bg-gradient-to-r from-sky-600 to-teal-600 text-white shadow-md shadow-sky-500/20 scale-105'
                  : 'bg-slate-100 text-slate-600 hover:bg-sky-50 hover:text-sky-600'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Image Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.05 }}
              onClick={() => {
                setActiveModalItem(item);
                setSliderPos(50);
              }}
              className="group relative rounded-3xl overflow-hidden aspect-[4/3] bg-slate-100 shadow-md hover:shadow-xl cursor-pointer"
            >
              <img
                src={item.imageUrl}
                alt={item.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              />

              {/* Hover Dark Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 p-6 flex flex-col justify-end text-left text-white">
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-sky-500/80 w-max mb-1">
                  {item.category}
                </span>
                <h3 className="text-base font-bold">{item.title}</h3>
                <p className="text-xs text-slate-300 mt-1 line-clamp-2">{item.description}</p>
                <div className="mt-3 flex items-center gap-1 text-xs font-semibold text-sky-300">
                  <Maximize2 className="w-3.5 h-3.5" />
                  <span>View Full Photo {item.beforeUrl ? '& Before/After' : ''}</span>
                </div>
              </div>

              {/* Transformation Badge */}
              {item.beforeUrl && (
                <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-teal-500 text-white text-[10px] font-bold shadow">
                  Before / After Slider
                </span>
              )}
            </motion.div>
          ))}
        </div>

      </div>

      {/* Lightbox / Before & After Modal */}
      {activeModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100 text-left">
            <button
              onClick={() => setActiveModalItem(null)}
              className="absolute top-4 right-4 z-30 p-2 rounded-full bg-slate-900/50 hover:bg-slate-900 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="p-6">
              {/* If Before/After smile transformation */}
              {activeModalItem.beforeUrl && activeModalItem.afterUrl ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="px-2.5 py-0.5 rounded-full bg-teal-100 text-teal-800 text-[10px] font-bold uppercase">
                        Interactive Comparison
                      </span>
                      <h3 className="text-xl font-extrabold text-slate-900 mt-1">{activeModalItem.title}</h3>
                    </div>
                    <span className="text-xs font-semibold text-slate-500">Drag handle to compare</span>
                  </div>

                  {/* Interactive Split Image Comparison Slider */}
                  <div className="relative w-full aspect-[16/9] rounded-2xl overflow-hidden select-none bg-slate-100">
                    {/* Before Image */}
                    <img
                      src={activeModalItem.beforeUrl}
                      alt="Before Treatment"
                      referrerPolicy="no-referrer"
                      className="absolute inset-0 w-full h-full object-cover"
                    />

                    {/* After Image (Clipped) */}
                    <div
                      className="absolute inset-0 overflow-hidden"
                      style={{ width: `${sliderPos}%` }}
                    >
                      <img
                        src={activeModalItem.afterUrl}
                        alt="After Treatment"
                        referrerPolicy="no-referrer"
                        className="absolute inset-0 w-full h-full object-cover max-w-none"
                      />
                    </div>

                    {/* Slider Line Divider */}
                    <div
                      className="absolute top-0 bottom-0 w-1 bg-white shadow-xl cursor-ew-resize z-20"
                      style={{ left: `${sliderPos}%` }}
                    >
                      <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white shadow-lg border border-slate-200 flex items-center justify-center text-slate-700">
                        <Sliders className="w-4 h-4" />
                      </div>
                    </div>

                    {/* Labels */}
                    <span className="absolute bottom-3 left-3 px-3 py-1 rounded-lg bg-teal-600 text-white text-xs font-bold z-10 shadow">
                      AFTER
                    </span>
                    <span className="absolute bottom-3 right-3 px-3 py-1 rounded-lg bg-slate-900/80 text-white text-xs font-bold z-10 shadow">
                      BEFORE
                    </span>

                    {/* Native range input overlay */}
                    <input
                      type="range"
                      min="0"
                      max="100"
                      value={sliderPos}
                      onChange={(e) => setSliderPos(Number(e.target.value))}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-30"
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="rounded-2xl overflow-hidden aspect-[16/9] bg-slate-100">
                    <img
                      src={activeModalItem.imageUrl}
                      alt={activeModalItem.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">{activeModalItem.title}</h3>
                    <p className="text-sm text-slate-600 mt-1">{activeModalItem.description}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
