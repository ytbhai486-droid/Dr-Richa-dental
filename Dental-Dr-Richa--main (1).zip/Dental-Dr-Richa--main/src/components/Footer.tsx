import React from 'react';
import { CLINIC_INFO, SERVICES } from '../data/clinicData';
import { Sparkles, Phone, Mail, MapPin, Heart, ShieldCheck, ArrowUp } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-950 text-slate-300 relative pt-16 pb-12 overflow-hidden border-t border-slate-800">
      {/* Decorative Glow */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-sky-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Section: Brand & Quick Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-slate-800/80 text-left">
          
          {/* Brand Info */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 to-teal-500 p-0.5 shadow-md">
                <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-sky-400" />
                </div>
              </div>
              <div>
                <h3 className="text-xl font-black text-white">{CLINIC_INFO.doctorName}</h3>
                <p className="text-xs text-sky-400 font-medium">Gentle & Modern Dentistry</p>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm">
              Providing world-class aesthetic, restorative, and pediatric dental care using advanced 3D scanning, laser tooth whitening, and painless techniques.
            </p>

            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs font-semibold text-teal-400">
              <ShieldCheck className="w-4 h-4" />
              <span>Hospital Grade Sterilisation</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-sm font-extrabold text-white uppercase tracking-wider">Quick Links</h4>
            <ul className="space-y-2 text-xs font-medium text-slate-400">
              <li>
                <a href="#hero" className="hover:text-sky-400 transition-colors">Home</a>
              </li>
              <li>
                <a href="#about" className="hover:text-sky-400 transition-colors">Meet Dr. Richa</a>
              </li>
              <li>
                <a href="#services" className="hover:text-sky-400 transition-colors">Dental Services</a>
              </li>
              <li>
                <a href="#why-us" className="hover:text-sky-400 transition-colors">Why Choose Us</a>
              </li>
              <li>
                <a href="#testimonials" className="hover:text-sky-400 transition-colors">Patient Reviews</a>
              </li>
              <li>
                <a href="#gallery" className="hover:text-sky-400 transition-colors">Clinic Gallery</a>
              </li>
              <li>
                <a href="#contact" className="hover:text-sky-400 transition-colors">Contact & Map</a>
              </li>
            </ul>
          </div>

          {/* Dental Services List */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-extrabold text-white uppercase tracking-wider">Services</h4>
            <ul className="grid grid-cols-1 gap-1.5 text-xs text-slate-400 font-medium">
              {SERVICES.slice(0, 7).map((s) => (
                <li key={s.id}>
                  <a href="#services" className="hover:text-teal-400 transition-colors">
                    • {s.title}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Details */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-sm font-extrabold text-white uppercase tracking-wider">Contact Info</h4>
            <div className="space-y-2.5 text-xs text-slate-400">
              <p className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-sky-400 shrink-0 mt-0.5" />
                <span>{CLINIC_INFO.address}</span>
              </p>
              <p className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-teal-400 shrink-0" />
                <a href={`tel:${CLINIC_INFO.phone}`} className="hover:text-white font-bold text-sky-400">
                  {CLINIC_INFO.phone}
                </a>
              </p>
              <p className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-sky-400 shrink-0" />
                <a href={`mailto:${CLINIC_INFO.email}`} className="hover:text-white">
                  {CLINIC_INFO.email}
                </a>
              </p>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} Dr. Richa Dental Clinic. All Rights Reserved.</p>

          <div className="flex items-center gap-4">
            <a href="#privacy" className="hover:text-slate-300 transition-colors">Privacy Policy</a>
            <span>•</span>
            <a href="#terms" className="hover:text-slate-300 transition-colors">Terms of Service</a>
            
            <button
              onClick={scrollToTop}
              className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition-colors ml-2"
              aria-label="Scroll to top"
            >
              <ArrowUp className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
