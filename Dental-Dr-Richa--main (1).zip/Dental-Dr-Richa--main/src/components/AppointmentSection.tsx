import React, { useState } from 'react';
import { SERVICES, CLINIC_INFO } from '../data/clinicData';
import { AppointmentFormData } from '../types';
import confetti from 'canvas-confetti';
import { motion } from 'motion/react';
import {
  Calendar,
  Clock,
  User,
  Phone,
  Mail,
  FileText,
  Sparkles,
  CheckCircle2,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';

interface AppointmentSectionProps {
  preselectedTreatment?: string;
}

export const AppointmentSection: React.FC<AppointmentSectionProps> = ({ preselectedTreatment }) => {
  const [formData, setFormData] = useState<AppointmentFormData>({
    fullName: '',
    phone: '',
    email: '',
    preferredDate: '',
    preferredTime: '10:00 AM',
    treatment: preselectedTreatment || 'Teeth Cleaning',
    message: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  // Update treatment when props change
  React.useEffect(() => {
    if (preselectedTreatment) {
      setFormData((prev) => ({ ...prev, treatment: preselectedTreatment }));
    }
  }, [preselectedTreatment]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);

      // Trigger celebratory confetti burst
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#38bdf8', '#14b8a6', '#0284c7'],
        });
      } catch (err) {
        // Fallback silently if canvas unavailable
      }
    }, 800);
  };

  const resetForm = () => {
    setSubmitted(false);
    setFormData({
      fullName: '',
      phone: '',
      email: '',
      preferredDate: '',
      preferredTime: '10:00 AM',
      treatment: 'Teeth Cleaning',
      message: '',
    });
  };

  return (
    <section id="book" className="py-20 lg:py-28 bg-slate-50 relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-10 left-1/3 w-[500px] h-[500px] bg-sky-200/30 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Form Intro & Clinic Info */}
          <div className="lg:col-span-5 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-sky-100 text-sky-800 text-xs font-bold uppercase tracking-wider">
              <Calendar className="w-3.5 h-3.5 text-sky-600" />
              <span>Easy Instant Booking</span>
            </div>

            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-tight">
              Book Your <br />
              <span className="bg-gradient-to-r from-sky-600 to-teal-600 bg-clip-text text-transparent">
                Appointment Online
              </span>
            </h2>

            <p className="text-slate-600 text-base sm:text-lg leading-relaxed">
              Schedule your visit with <strong className="text-slate-900 font-semibold">{CLINIC_INFO.doctorName}</strong> in less than 60 seconds. Choose your preferred time slot and treatment.
            </p>

            <div className="space-y-4 pt-2">
              <div className="flex items-start gap-3 p-4 rounded-2xl bg-white shadow-sm border border-slate-100">
                <CheckCircle2 className="w-5 h-5 text-teal-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900">Zero Wait Time Guarantee</h4>
                  <p className="text-xs text-slate-500">We respect your schedule with scheduled, zero-delay appointments.</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 rounded-2xl bg-white shadow-sm border border-slate-100">
                <ShieldCheck className="w-5 h-5 text-sky-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-xs sm:text-sm font-bold text-slate-900">Instant SMS & WhatsApp Confirmation</h4>
                  <p className="text-xs text-slate-500">Get automated digital appointment receipts and location directions.</p>
                </div>
              </div>
            </div>

            {/* Direct Phone Emergency Box */}
            <div className="p-5 rounded-2xl bg-sky-600 text-white shadow-lg space-y-1">
              <p className="text-xs font-bold text-sky-100 uppercase tracking-wider">Need Immediate Dental Relief?</p>
              <p className="text-lg font-black">{CLINIC_INFO.phone}</p>
              <p className="text-xs text-sky-100">Direct hotline available for same-day emergency visits.</p>
            </div>
          </div>

          {/* Right Column: Glassmorphism Appointment Form Card */}
          <div className="lg:col-span-7">
            <div className="bg-white/90 backdrop-blur-xl rounded-3xl p-6 sm:p-10 shadow-2xl shadow-sky-900/10 border border-sky-100 text-left">
              
              {submitted ? (
                /* Success Confirmation State */
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="py-8 text-center space-y-6"
                >
                  <div className="w-20 h-20 rounded-full bg-teal-100 text-teal-600 flex items-center justify-center mx-auto shadow-inner">
                    <CheckCircle2 className="w-10 h-10 animate-bounce" />
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-2xl font-black text-slate-900">Appointment Request Received!</h3>
                    <p className="text-sm text-slate-600 max-w-md mx-auto">
                      Thank you, <strong className="text-slate-900">{formData.fullName}</strong>. We have reserved your requested slot for <strong className="text-sky-700">{formData.treatment}</strong>.
                    </p>
                  </div>

                  {/* Summary Card */}
                  <div className="p-5 rounded-2xl bg-sky-50/80 border border-sky-100 text-xs sm:text-sm text-slate-700 space-y-2 text-left max-w-md mx-auto">
                    <div className="flex justify-between border-b border-sky-100 pb-2">
                      <span className="text-slate-500 font-semibold">Doctor:</span>
                      <span className="font-bold">{CLINIC_INFO.doctorName}</span>
                    </div>
                    <div className="flex justify-between border-b border-sky-100 pb-2">
                      <span className="text-slate-500 font-semibold">Requested Date:</span>
                      <span className="font-bold">{formData.preferredDate || 'Upcoming Date'}</span>
                    </div>
                    <div className="flex justify-between border-b border-sky-100 pb-2">
                      <span className="text-slate-500 font-semibold">Time Slot:</span>
                      <span className="font-bold">{formData.preferredTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500 font-semibold">Contact Phone:</span>
                      <span className="font-bold">{formData.phone}</span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-500">
                    A confirmation SMS & WhatsApp reminder has been dispatched to <strong>{formData.phone}</strong>.
                  </p>

                  <button
                    onClick={resetForm}
                    className="px-6 py-3 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-sky-600 to-teal-600 shadow-md hover:scale-105 transition-transform"
                  >
                    Book Another Appointment
                  </button>
                </motion.div>
              ) : (
                /* Main Appointment Form */
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    {/* Full Name */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Full Name *
                      </label>
                      <div className="relative">
                        <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                        <input
                          type="text"
                          required
                          placeholder="e.g. Eleanor Vance"
                          value={formData.fullName}
                          onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                        />
                      </div>
                    </div>

                    {/* Phone Number */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Phone Number *
                      </label>
                      <div className="relative">
                        <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                        <input
                          type="tel"
                          required
                          placeholder="e.g. +1 (555) 019-2831"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                        />
                      </div>
                    </div>

                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    {/* Email */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Email Address
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                        <input
                          type="email"
                          placeholder="e.g. eleanor@example.com"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                        />
                      </div>
                    </div>

                    {/* Treatment Required */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Treatment Required *
                      </label>
                      <select
                        required
                        value={formData.treatment}
                        onChange={(e) => setFormData({ ...formData, treatment: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 bg-white"
                      >
                        {SERVICES.map((s) => (
                          <option key={s.id} value={s.title}>
                            {s.title}
                          </option>
                        ))}
                      </select>
                    </div>

                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    
                    {/* Preferred Date */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Preferred Date *
                      </label>
                      <div className="relative">
                        <Calendar className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                        <input
                          type="date"
                          required
                          value={formData.preferredDate}
                          onChange={(e) => setFormData({ ...formData, preferredDate: e.target.value })}
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                        />
                      </div>
                    </div>

                    {/* Preferred Time Slot */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Preferred Time *
                      </label>
                      <div className="relative">
                        <Clock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                        <select
                          required
                          value={formData.preferredTime}
                          onChange={(e) => setFormData({ ...formData, preferredTime: e.target.value })}
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 bg-white"
                        >
                          <option value="09:00 AM">09:00 AM - Morning</option>
                          <option value="10:30 AM">10:30 AM - Morning</option>
                          <option value="12:00 PM">12:00 PM - Midday</option>
                          <option value="03:00 PM">03:00 PM - Afternoon</option>
                          <option value="05:30 PM">05:30 PM - Evening</option>
                          <option value="07:00 PM">07:00 PM - Late Evening</option>
                        </select>
                      </div>
                    </div>

                  </div>

                  {/* Message / Symptoms */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Message / Special Requests
                    </label>
                    <div className="relative">
                      <FileText className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                      <textarea
                        rows={3}
                        placeholder="Describe any pain, dental anxiety, or specific requirements..."
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500"
                      />
                    </div>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-4 rounded-2xl text-sm font-bold text-white bg-gradient-to-r from-sky-600 via-teal-600 to-sky-600 bg-[length:200%_auto] hover:bg-right transition-all duration-500 shadow-xl shadow-sky-500/25 flex items-center justify-center gap-2 hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50"
                  >
                    {loading ? (
                      <span className="animate-spin w-5 h-5 border-2 border-white border-t-transparent rounded-full" />
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        <span>Book Appointment Now</span>
                      </>
                    )}
                  </button>

                  <p className="text-[11px] text-slate-500 text-center">
                    🔒 Your personal & medical info is 100% confidential under HIPAA standards.
                  </p>
                </form>
              )}

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
