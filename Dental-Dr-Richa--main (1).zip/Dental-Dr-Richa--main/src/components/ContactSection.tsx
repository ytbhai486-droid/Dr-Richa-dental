import React from 'react';
import { CLINIC_INFO } from '../data/clinicData';
import { motion } from 'motion/react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  MessageCircle,
  Share2,
  Instagram,
  Facebook,
  Youtube,
  Linkedin,
  ExternalLink,
  Sparkles
} from 'lucide-react';

export const ContactSection: React.FC = () => {
  return (
    <section id="contact" className="py-20 lg:py-28 bg-white relative overflow-hidden">
      {/* Background accents */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-teal-100/40 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-teal-100 text-teal-800 text-xs font-bold uppercase tracking-wider">
            <MapPin className="w-3.5 h-3.5 text-teal-600" />
            <span>Visit Our Clinic</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Contact & <span className="bg-gradient-to-r from-sky-600 to-teal-600 bg-clip-text text-transparent">Location</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            We are conveniently located in the city center with dedicated parking and rapid accessibility.
          </p>
        </div>

        {/* Grid layout: Info & Google Map */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Contact Cards */}
          <div className="lg:col-span-5 space-y-6 text-left">
            
            {/* Address Box */}
            <div className="p-6 rounded-3xl bg-slate-50 border border-slate-100 hover:border-sky-200 transition-colors space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Clinic Address</h3>
                  <p className="text-sm font-bold text-slate-900 mt-0.5">{CLINIC_INFO.address}</p>
                </div>
              </div>
            </div>

            {/* Phone & Direct Helpline */}
            <div className="p-6 rounded-3xl bg-slate-50 border border-slate-100 hover:border-sky-200 transition-colors space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-600 flex items-center justify-center shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Phone & Emergency Care</h3>
                  <a href={`tel:${CLINIC_INFO.phone}`} className="text-sm font-bold text-sky-600 hover:underline block mt-0.5">
                    {CLINIC_INFO.phone}
                  </a>
                  <p className="text-xs text-slate-500 mt-0.5">Direct Line: {CLINIC_INFO.directPhone}</p>
                </div>
              </div>
            </div>

            {/* Email Box */}
            <div className="p-6 rounded-3xl bg-slate-50 border border-slate-100 hover:border-sky-200 transition-colors space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Email Inquiry</h3>
                  <a href={`mailto:${CLINIC_INFO.email}`} className="text-sm font-bold text-slate-900 hover:text-sky-600 block mt-0.5">
                    {CLINIC_INFO.email}
                  </a>
                </div>
              </div>
            </div>

            {/* Working Hours Box */}
            <div className="p-6 rounded-3xl bg-slate-50 border border-slate-100 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Working Hours</h3>
                  <p className="text-xs font-bold text-slate-800 mt-1">{CLINIC_INFO.hours.weekdays}</p>
                  <p className="text-xs font-semibold text-slate-600">{CLINIC_INFO.hours.sunday}</p>
                  <p className="text-xs font-bold text-teal-600 mt-1">{CLINIC_INFO.hours.emergency}</p>
                </div>
              </div>
            </div>

            {/* Direct WhatsApp Chat Action Button */}
            <a
              href={CLINIC_INFO.social.whatsapp}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 w-full py-4 rounded-2xl text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-500 shadow-lg shadow-emerald-600/20 transition-all hover:-translate-y-0.5"
            >
              <MessageCircle className="w-5 h-5 fill-white text-emerald-600" />
              <span>Chat directly on WhatsApp</span>
            </a>

            {/* Social Media Links */}
            <div className="pt-2 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Follow Dr. Richa:</span>
              <div className="flex items-center gap-2">
                <a
                  href={CLINIC_INFO.social.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-pink-100 hover:text-pink-600 text-slate-600 flex items-center justify-center transition-colors"
                  aria-label="Instagram"
                >
                  <Instagram className="w-4 h-4" />
                </a>
                <a
                  href={CLINIC_INFO.social.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-blue-100 hover:text-blue-600 text-slate-600 flex items-center justify-center transition-colors"
                  aria-label="Facebook"
                >
                  <Facebook className="w-4 h-4" />
                </a>
                <a
                  href={CLINIC_INFO.social.youtube}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-red-100 hover:text-red-600 text-slate-600 flex items-center justify-center transition-colors"
                  aria-label="YouTube"
                >
                  <Youtube className="w-4 h-4" />
                </a>
                <a
                  href={CLINIC_INFO.social.linkedin}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-9 h-9 rounded-xl bg-slate-100 hover:bg-sky-100 hover:text-sky-600 text-slate-600 flex items-center justify-center transition-colors"
                  aria-label="LinkedIn"
                >
                  <Linkedin className="w-4 h-4" />
                </a>
              </div>
            </div>

          </div>

          {/* Right Column: Embedded Google Map Frame */}
          <div className="lg:col-span-7 h-full min-h-[450px]">
            <div className="w-full h-full min-h-[480px] rounded-3xl overflow-hidden border border-slate-200 shadow-xl relative bg-slate-100">
              <iframe
                title="Dr. Richa Dental Clinic Location"
                src={CLINIC_INFO.googleMapsEmbed}
                width="100%"
                height="100%"
                style={{ border: 0, minHeight: '480px' }}
                allowFullScreen={false}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="w-full h-full filter saturate-110"
              />

              {/* Floating Location Marker Card */}
              <div className="absolute top-4 left-4 p-4 rounded-2xl bg-white/90 backdrop-blur-md border border-white shadow-lg text-left max-w-xs">
                <div className="flex items-center gap-2 text-sky-600 font-bold text-xs uppercase tracking-wide">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Dr. Richa Dental Clinic</span>
                </div>
                <p className="text-xs font-bold text-slate-900 mt-1">Valet Parking Available</p>
                <p className="text-[11px] text-slate-500 mt-0.5">Wheelchair Accessible • Elevator Access</p>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
