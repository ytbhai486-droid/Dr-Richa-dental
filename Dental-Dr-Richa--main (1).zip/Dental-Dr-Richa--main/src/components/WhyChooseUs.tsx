import React from 'react';
import { WHY_CHOOSE_US } from '../data/clinicData';
import { motion } from 'motion/react';
import { Award, Cpu, Feather, CreditCard, ShieldAlert, CalendarCheck, CheckCircle2, Sparkles } from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Award':
        return <Award className="w-6 h-6 text-sky-600" />;
      case 'Cpu':
        return <Cpu className="w-6 h-6 text-teal-600" />;
      case 'Feather':
        return <Feather className="w-6 h-6 text-sky-600" />;
      case 'CreditCard':
        return <CreditCard className="w-6 h-6 text-emerald-600" />;
      case 'ShieldAlert':
        return <ShieldAlert className="w-6 h-6 text-indigo-600" />;
      case 'CalendarCheck':
        return <CalendarCheck className="w-6 h-6 text-teal-600" />;
      default:
        return <CheckCircle2 className="w-6 h-6 text-sky-600" />;
    }
  };

  return (
    <section id="why-us" className="py-20 lg:py-28 bg-white relative overflow-hidden">
      {/* Background Accent Gradients */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-sky-100/50 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-teal-100 text-teal-800 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-teal-600" />
            <span>The Dr. Richa Standard</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            Why Choose <span className="bg-gradient-to-r from-sky-600 to-teal-600 bg-clip-text text-transparent">Dr. Richa Dental Clinic</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            We blend clinical excellence, modern 3D dentistry, and warm hospitality to make your visit stress-free.
          </p>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {WHY_CHOOSE_US.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
              className="p-8 rounded-3xl bg-slate-50/80 hover:bg-white border border-slate-100 hover:border-sky-200 shadow-sm hover:shadow-xl hover:shadow-sky-500/10 transition-all duration-300 group text-left"
            >
              <div className="w-12 h-12 rounded-2xl bg-white shadow-sm border border-slate-100 flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-sky-50 transition-all">
                {getIcon(item.iconName)}
              </div>

              <h3 className="text-xl font-bold text-slate-900 group-hover:text-sky-600 transition-colors">
                {item.title}
              </h3>

              <p className="text-xs sm:text-sm text-slate-600 mt-3 leading-relaxed">
                {item.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Sterilization & Safety Highlight Banner */}
        <div className="mt-16 p-8 rounded-3xl bg-gradient-to-r from-slate-900 via-sky-950 to-teal-950 text-white relative overflow-hidden shadow-2xl">
          <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px] opacity-20 pointer-events-none" />

          <div className="relative z-10 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            <div className="md:col-span-8 space-y-2 text-left">
              <span className="px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30 text-xs font-semibold tracking-wide">
                100% Infection Control Guarantee
              </span>
              <h3 className="text-2xl sm:text-3xl font-black">Sterilization & Safety Standards</h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Your health is our top priority. Our clinic utilizes hospital-grade Class-B Autoclave steam sterilizers, single-use disposable barrier packs, and HEPA air purification in every treatment room.
              </p>
            </div>

            <div className="md:col-span-4 flex items-center justify-start md:justify-end gap-3">
              <div className="px-5 py-3 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 text-center">
                <p className="text-2xl font-black text-sky-300">Class-B</p>
                <p className="text-[10px] uppercase font-bold text-slate-300">Autoclave Sterilized</p>
              </div>
              <div className="px-5 py-3 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 text-center">
                <p className="text-2xl font-black text-teal-300">0%</p>
                <p className="text-[10px] uppercase font-bold text-slate-300">Cross-Contamination</p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
