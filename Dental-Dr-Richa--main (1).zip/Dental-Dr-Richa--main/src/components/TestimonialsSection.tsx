import React, { useState, useEffect } from 'react';
import { TESTIMONIALS } from '../data/clinicData';
import { Testimonial } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { Star, ChevronLeft, ChevronRight, Quote, CheckCircle2, MessageSquarePlus, X } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const [reviews, setReviews] = useState<Testimonial[]>(TESTIMONIALS);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);

  // New review form state
  const [newReview, setNewReview] = useState({
    name: '',
    role: '',
    treatment: 'Teeth Cleaning',
    rating: 5,
    review: '',
  });

  // Auto-slide carousel
  useEffect(() => {
    if (isPaused) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % reviews.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [reviews.length, isPaused]);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + reviews.length) % reviews.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % reviews.length);
  };

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.name || !newReview.review) return;

    const created: Testimonial = {
      id: Date.now().toString(),
      name: newReview.name,
      role: newReview.role || 'Verified Patient',
      avatar: `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=200&auto=format&fit=crop`,
      rating: newReview.rating,
      treatment: newReview.treatment,
      review: newReview.review,
      date: 'Just now',
      verified: true,
    };

    setReviews([created, ...reviews]);
    setShowReviewModal(false);
    setNewReview({ name: '', role: '', treatment: 'Teeth Cleaning', rating: 5, review: '' });
  };

  return (
    <section id="testimonials" className="py-20 lg:py-28 bg-slate-50 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-1/2 left-10 w-72 h-72 bg-sky-200/40 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-100 text-amber-800 text-xs font-bold uppercase tracking-wider">
            <Star className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
            <span>Real Patient Experiences</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight">
            What Our <span className="bg-gradient-to-r from-sky-600 to-teal-600 bg-clip-text text-transparent">Patients Say</span>
          </h2>
          <p className="text-slate-600 text-base sm:text-lg">
            Read authentic reviews from patients who experienced gentle, painless smile transformations at our clinic.
          </p>
        </div>

        {/* Carousel Outer Wrapper */}
        <div
          className="relative max-w-4xl mx-auto"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.4 }}
              className="p-8 sm:p-12 rounded-3xl bg-white shadow-xl shadow-sky-500/10 border border-sky-100 relative text-left"
            >
              <Quote className="absolute top-8 right-8 w-16 h-16 text-sky-100 pointer-events-none" />

              <div className="space-y-6 relative z-10">
                {/* 5-Star Rating & Verified Badge */}
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-5 h-5 ${
                          i < reviews[currentIndex].rating
                            ? 'fill-amber-400 text-amber-400'
                            : 'text-slate-200'
                        }`}
                      />
                    ))}
                  </div>

                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 text-teal-700 text-xs font-bold border border-teal-200">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Verified Patient</span>
                  </span>
                </div>

                {/* Review Text */}
                <p className="text-base sm:text-lg text-slate-700 leading-relaxed italic font-medium">
                  "{reviews[currentIndex].review}"
                </p>

                {/* Patient Profile */}
                <div className="flex items-center justify-between pt-4 border-t border-slate-100 flex-wrap gap-4">
                  <div className="flex items-center gap-4">
                    <img
                      src={reviews[currentIndex].avatar}
                      alt={reviews[currentIndex].name}
                      referrerPolicy="no-referrer"
                      className="w-12 h-12 rounded-full object-cover border-2 border-sky-200 shadow-sm"
                    />
                    <div>
                      <h4 className="text-base font-bold text-slate-900">{reviews[currentIndex].name}</h4>
                      <p className="text-xs text-slate-500">{reviews[currentIndex].role}</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-sky-50 text-sky-700">
                      Treatment: {reviews[currentIndex].treatment}
                    </span>
                    <p className="text-[10px] text-slate-400 mt-1">{reviews[currentIndex].date}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Controls */}
          <div className="flex items-center justify-between mt-8">
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrev}
                className="w-10 h-10 rounded-full bg-white border border-slate-200 shadow-sm flex items-center justify-center text-slate-700 hover:bg-sky-50 hover:text-sky-600 transition-colors"
                aria-label="Previous review"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={handleNext}
                className="w-10 h-10 rounded-full bg-white border border-slate-200 shadow-sm flex items-center justify-center text-slate-700 hover:bg-sky-50 hover:text-sky-600 transition-colors"
                aria-label="Next review"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

            {/* Pagination Dots */}
            <div className="flex items-center gap-2">
              {reviews.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  className={`h-2 rounded-full transition-all ${
                    idx === currentIndex ? 'w-8 bg-sky-600' : 'w-2 bg-slate-300'
                  }`}
                  aria-label={`Go to slide ${idx + 1}`}
                />
              ))}
            </div>

            {/* Submit Review Button */}
            <button
              onClick={() => setShowReviewModal(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-sky-700 bg-sky-50 hover:bg-sky-100 border border-sky-200 transition-colors"
            >
              <MessageSquarePlus className="w-3.5 h-3.5" />
              <span>Write a Review</span>
            </button>
          </div>
        </div>

      </div>

      {/* Write a Review Modal */}
      {showReviewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl space-y-4 text-left border border-sky-100">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-900">Share Your Experience</h3>
              <button
                onClick={() => setShowReviewModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddReview} className="space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block text-slate-700 font-medium mb-1">Your Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Sarah Jenkins"
                  value={newReview.name}
                  onChange={(e) => setNewReview({ ...newReview, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Profession / Role</label>
                <input
                  type="text"
                  placeholder="e.g. Architect"
                  value={newReview.role}
                  onChange={(e) => setNewReview({ ...newReview, role: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Treatment Received</label>
                <select
                  value={newReview.treatment}
                  onChange={(e) => setNewReview({ ...newReview, treatment: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500"
                >
                  <option value="Teeth Cleaning">Teeth Cleaning</option>
                  <option value="Teeth Whitening">Teeth Whitening</option>
                  <option value="Dental Implants">Dental Implants</option>
                  <option value="Root Canal Treatment">Root Canal Treatment</option>
                  <option value="Clear Aligners">Clear Aligners</option>
                  <option value="Smile Makeover">Smile Makeover</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Rating (1-5 Stars)</label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setNewReview({ ...newReview, rating: star })}
                      className="p-1 text-2xl focus:outline-none"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          star <= newReview.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-300'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">Your Review *</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Tell us about Dr. Richa and your treatment experience..."
                  value={newReview.review}
                  onChange={(e) => setNewReview({ ...newReview, review: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowReviewModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-white font-semibold bg-gradient-to-r from-sky-600 to-teal-600 shadow-md"
                >
                  Post Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
};
