import React from 'react';
import { Service } from '../types';
import { X, Clock, DollarSign, CheckCircle2, Calendar, HelpCircle, Sparkles, ChevronRight } from 'lucide-react';

interface ServiceModalProps {
  service: Service | null;
  onClose: () => void;
  onBookTreatment: (serviceTitle: string) => void;
}

export const ServiceModal: React.FC<ServiceModalProps> = ({ service, onClose, onBookTreatment }) => {
  if (!service) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-sky-100 max-h-[90vh] flex flex-col my-auto">
        
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-sky-600 via-teal-600 to-sky-700 text-white relative flex items-start justify-between">
          <div className="space-y-1 pr-8 text-left">
            <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-white text-[10px] font-bold uppercase tracking-wider">
              {service.category} Care
            </span>
            <h3 className="text-2xl font-black">{service.title}</h3>
            <p className="text-sky-100 text-xs sm:text-sm">{service.shortDesc}</p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1 text-left">
          {/* Quick Stats Bar */}
          <div className="grid grid-cols-2 gap-4 p-4 rounded-2xl bg-sky-50/80 border border-sky-100">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-sky-500 text-white flex items-center justify-center shrink-0">
                <Clock className="w-4 h-4" />
              </div>
              <div>
                <p className="text-[11px] text-slate-500 font-semibold uppercase">Duration</p>
                <p className="text-xs font-bold text-slate-900">{service.duration}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-teal-500 text-white flex items-center justify-center shrink-0">
                <DollarSign className="w-4 h-4" />
              </div>
              <div>
                <p className="text-[11px] text-slate-500 font-semibold uppercase">Pricing</p>
                <p className="text-xs font-bold text-slate-900">{service.estimatedCost}</p>
              </div>
            </div>
          </div>

          {/* Full Description */}
          <div className="space-y-2">
            <h4 className="text-sm font-extrabold text-slate-900">About Procedure</h4>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">{service.fullDesc}</p>
          </div>

          {/* Key Benefits */}
          <div className="space-y-3">
            <h4 className="text-sm font-extrabold text-slate-900">Key Benefits</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {service.benefits.map((benefit, index) => (
                <div key={index} className="flex items-start gap-2.5 text-xs text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                  <span>{benefit}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Procedure Steps */}
          <div className="space-y-3 pt-2">
            <h4 className="text-sm font-extrabold text-slate-900">Procedure Steps</h4>
            <div className="space-y-2">
              {service.procedureSteps.map((step, index) => (
                <div key={index} className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 text-xs text-slate-700 border border-slate-100">
                  <span className="w-5 h-5 rounded-full bg-sky-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0">
                    {index + 1}
                  </span>
                  <span className="pt-0.5">{step}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Procedure FAQs */}
          {service.faqs && service.faqs.length > 0 && (
            <div className="space-y-3 pt-2">
              <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-sky-600" />
                <span>Frequently Asked Questions</span>
              </h4>
              <div className="space-y-2">
                {service.faqs.map((faq, index) => (
                  <div key={index} className="p-3 rounded-xl bg-sky-50/50 border border-sky-100 text-xs">
                    <p className="font-bold text-slate-900">Q: {faq.question}</p>
                    <p className="text-slate-600 mt-1">A: {faq.answer}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer CTA */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between gap-4">
          <p className="text-xs text-slate-500 hidden sm:block">Need personalized dental advice?</p>
          
          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-200/60 transition-colors"
            >
              Close
            </button>
            <button
              onClick={() => {
                onClose();
                onBookTreatment(service.title);
              }}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-sky-600 to-teal-600 hover:from-sky-500 hover:to-teal-500 shadow-md shadow-sky-500/20"
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>Book This Treatment</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
