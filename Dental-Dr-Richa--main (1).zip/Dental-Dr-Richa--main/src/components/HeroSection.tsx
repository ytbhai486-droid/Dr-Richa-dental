import React from 'react';
import { CLINIC_INFO, CLINIC_STATS } from '../data/clinicData';
import { ToothCanvas } from './3d/ToothCanvas';
import { motion } from 'motion/react';
import {
  Calendar,
  Phone,
  Sparkles,
  ShieldCheck,
  Star,
  Award,
  Smile,
  CheckCircle2,
  Clock,
  HeartHandshake
} from 'lucide-react';

interface HeroSectionProps {
  onBookClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onBookClick }) => {
  return (
    <section id="hero" className="relative pt-28 pb-16 lg:pt-36 lg:pb-24 overflow-hidden bg-slate-50/50">
      {/* Background Decorative Glow Circles */}
      <div className="absolute top-10 left-1/4 w-96 h-96 bg-sky-200/40 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-[500px] h-[500px] bg-teal-200/30 rounded-full blur-3xl pointer-events-none" />
      
      {/* Geometric futuristic mesh lines */}
      <div className="absolute inset-0 bg-[radial-gradient(#e0f2fe_1px,transparent_1px)] [background-size:24px_24px] opacity-60 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Hero Content Column */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
            className="lg:col-span-7 space-y-6 text-left"
          >
            {/* Top Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-100/80 border border-sky-200 text-sky-800 text-xs font-semibold backdrop-blur-md shadow-sm">
              <Sparkles className="w-4 h-4 text-sky-600 animate-spin" style={{ animationDuration: '6s' }} />
              <span>Premium Dental Care in City Center</span>
              <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
              <span className="text-slate-600 font-normal">100% Painless Tech</span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-[1.12]">
              Your Smile, <br />
              <span className="bg-gradient-to-r from-sky-600 via-teal-600 to-sky-700 bg-clip-text text-transparent">
                Our Priority
              </span>
            </h1>

            {/* Subheading */}
            <p className="text-base sm:text-lg text-slate-600 font-normal max-w-2xl leading-relaxed">
              Expert Dental Care by <strong className="text-slate-900 font-semibold">{CLINIC_INFO.doctorName}</strong> – Gentle, Modern & Affordable Dentistry with advanced 3D scanning, laser teeth whitening, and instant painless care.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 pt-2">
              <button
                onClick={onBookClick}
                className="group relative inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-2xl text-sm font-bold text-white bg-gradient-to-r from-sky-600 via-teal-600 to-sky-600 bg-[length:200%_auto] hover:bg-right transition-all duration-500 shadow-lg shadow-sky-500/25 hover:shadow-xl hover:shadow-sky-500/35 hover:-translate-y-0.5 active:translate-y-0"
              >
                <Calendar className="w-4 h-4 group-hover:scale-110 transition-transform" />
                <span>Book Appointment</span>
              </button>

              <a
                href={`tel:${CLINIC_INFO.phone}`}
                className="inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-2xl text-sm font-bold text-slate-800 bg-white/90 hover:bg-white border border-slate-200 hover:border-sky-300 shadow-sm hover:shadow-md transition-all text-center"
              >
                <Phone className="w-4 h-4 text-sky-600" />
                <span>Call Now: {CLINIC_INFO.phone}</span>
              </a>
            </div>

            {/* Quick Trust Badges Row */}
            <div className="pt-6 border-t border-slate-200/80 grid grid-cols-3 gap-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-sky-100 flex items-center justify-center text-sky-700 shrink-0">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">10+ Yrs Exp.</p>
                  <p className="text-[11px] text-slate-500">Expert Specialist</p>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-teal-100 flex items-center justify-center text-teal-700 shrink-0">
                  <Star className="w-5 h-5 fill-teal-500 text-teal-500" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">4.9 ★ Rating</p>
                  <p className="text-[11px] text-slate-500">12,500+ Patients</p>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-sky-100 flex items-center justify-center text-sky-700 shrink-0">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-900">Class-B Autoclave</p>
                  <p className="text-[11px] text-slate-500">100% Sterilized</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Dr. Richa Main Hero Portrait with Floating 3D Elements */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-5 relative"
          >
            {/* Main Glass Card Frame */}
            <div className="relative rounded-3xl bg-white/70 backdrop-blur-xl border border-white/80 p-3 shadow-2xl shadow-sky-900/10 group">
              
              {/* Doctor Image Container */}
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3] sm:aspect-[1/1] lg:aspect-[4/5] bg-gradient-to-b from-sky-100 to-teal-50">
                <img
                  src={CLINIC_INFO.doctorImageUrl}
                  alt="Dr. Richa - BDS Senior Dentist"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-top hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent pointer-events-none" />

                {/* Bottom Overlay Label */}
                <div className="absolute bottom-4 left-4 right-4 p-3 rounded-xl bg-white/85 backdrop-blur-md border border-white/90 shadow-lg flex items-center justify-between">
                  <div>
                    <h3 className="text-sm font-extrabold text-slate-900">{CLINIC_INFO.doctorName}</h3>
                    <p className="text-[11px] text-sky-700 font-medium">{CLINIC_INFO.doctorTitle}</p>
                  </div>
                  <span className="px-2.5 py-1 rounded-full bg-teal-500 text-white text-[10px] font-bold tracking-wide uppercase">
                    Available Today
                  </span>
                </div>
              </div>

              {/* FLOATING 3D DENTAL ELEMENTS & BADGES */}
              
              {/* Floating Element 1: 3D Tooth Canvas Box */}
              <motion.div
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                className="absolute -top-8 -left-8 w-36 h-36 sm:w-40 sm:h-40 bg-white/90 backdrop-blur-md rounded-2xl border border-sky-100 p-1 shadow-xl shadow-sky-500/15 hidden sm:block pointer-events-auto z-20"
              >
                <ToothCanvas className="w-full h-full" interactive={true} />
              </motion.div>

              {/* Floating Element 2: Dental Implant Icon Badge */}
              <motion.div
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
                className="absolute -bottom-6 -left-6 bg-white/90 backdrop-blur-md rounded-2xl border border-teal-100 p-3 shadow-xl flex items-center gap-3 z-20"
              >
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-500 to-sky-600 text-white flex items-center justify-center text-lg shadow-md">
                  🦷
                </div>
                <div className="text-left">
                  <p className="text-xs font-bold text-slate-900">3D Implants & Aligners</p>
                  <p className="text-[10px] text-teal-700 font-medium">Digital Guided Care</p>
                </div>
              </motion.div>

              {/* Floating Element 3: Smile Icon / Rating Badge */}
              <motion.div
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 4.2, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
                className="absolute top-12 -right-6 bg-white/90 backdrop-blur-md rounded-2xl border border-sky-100 p-3 shadow-xl z-20 text-left hidden sm:flex items-center gap-2.5"
              >
                <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center font-bold">
                  ★ 4.9
                </div>
                <div>
                  <p className="text-xs font-extrabold text-slate-900">Top Rated Dentist</p>
                  <p className="text-[10px] text-slate-500">100% Verified Reviews</p>
                </div>
              </motion.div>

              {/* Floating Element 4: Dental Mirror & Hygiene Badge */}
              <motion.div
                animate={{ x: [0, 6, 0] }}
                transition={{ duration: 3.8, repeat: Infinity, ease: 'easeInOut', delay: 1.2 }}
                className="absolute bottom-20 -right-8 bg-sky-600 text-white backdrop-blur-md rounded-2xl p-2.5 shadow-xl z-20 hidden md:flex items-center gap-2 text-xs font-bold"
              >
                <Smile className="w-4 h-4 text-teal-300" />
                <span>Painless Dentistry</span>
              </motion.div>

            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};
