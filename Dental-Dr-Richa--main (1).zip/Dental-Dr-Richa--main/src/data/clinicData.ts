import { Service, Testimonial, GalleryItem, ClinicStat } from '../types';

export const CLINIC_INFO = {
  name: 'Dr. Richa Dental Clinic',
  doctorName: 'Dr. Richa',
  doctorTitle: 'BDS • Senior Aesthetic & Implant Specialist',
  doctorExp: '10+ Years Experience',
  address: '102 Smile Care Dental Tower, Healthcare Avenue, City Center, NY 10001',
  phone: '+1 (800) 555-SMILE',
  directPhone: '+1 (555) 392-8411',
  whatsapp: '+15553928411',
  email: 'contact@drrichadental.com',
  googleMapsEmbed: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.2157022513926!2d-73.98784412342594!3d40.75797473483321!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25855c8ba8177%3A0x7e1277f0d04c0e62!2sTimes%20Square!5e0!3m2!1sen!2sus!4v1700000000000!5m2!1sen!2sus',
  hours: {
    weekdays: 'Monday - Saturday: 9:00 AM – 8:00 PM',
    sunday: 'Sunday: By Appointment Only',
    emergency: '24/7 Emergency Care Available',
  },
  social: {
    instagram: 'https://instagram.com',
    facebook: 'https://facebook.com',
    youtube: 'https://youtube.com',
    linkedin: 'https://linkedin.com',
    whatsapp: 'https://wa.me/15553928411',
  },
  // Dr Richa portrait image URL - clean professional female dentist portrait
  doctorImageUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?q=80&w=1200&auto=format&fit=crop',
  // Alternative high res clinic room
  heroClinicBgUrl: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=80&w=1600&auto=format&fit=crop',
};

export const CLINIC_STATS: ClinicStat[] = [
  {
    label: 'Happy Patients',
    value: 12500,
    suffix: '+',
    description: 'Smiles transformed across 10 years of care',
    iconName: 'Smile',
  },
  {
    label: 'Years Experience',
    value: 10,
    suffix: '+ Yrs',
    description: 'Expertise in modern aesthetic & implant dentistry',
    iconName: 'Award',
  },
  {
    label: 'Successful Procedures',
    value: 15000,
    suffix: '+',
    description: 'From painless root canals to full smile makeovers',
    iconName: 'CheckCircle2',
  },
  {
    label: 'Pain-Free Rate',
    value: 99.8,
    suffix: '%',
    description: 'Gentle techniques and computer-guided local care',
    iconName: 'Sparkles',
  },
];

export const SERVICES: Service[] = [
  {
    id: 'teeth-cleaning',
    title: 'Teeth Cleaning',
    shortDesc: 'Ultrasonic scaling & polishing for healthy gums and fresh breath.',
    fullDesc: 'Our advanced ultrasonic dental cleaning removes plaque, stubborn tartar, and surface stains that regular brushing cannot reach. Protects gums against gingivitis and gives you a instantly refreshed smile.',
    iconName: 'Sparkles',
    category: 'preventive',
    duration: '30 - 45 mins',
    estimatedCost: 'Affordable / Insurance Covered',
    benefits: [
      'Removes tough plaque and calculus buildup',
      'Prevents gum disease and bad breath',
      'Pain-free ultrasonic vibration technology',
      'Includes complimentary oral cancer screening',
    ],
    procedureSteps: [
      'Comprehensive oral examination with intraoral camera',
      'Ultrasonic tartar and plaque removal',
      'Prophylaxis tooth polishing with fluoride application',
      'Personalized oral hygiene care plan',
    ],
    faqs: [
      {
        question: 'How often should I get my teeth professionally cleaned?',
        answer: 'We recommend professional cleaning every 6 months to maintain optimal gum health and catch early signs of decay.',
      },
      {
        question: 'Does dental cleaning hurt?',
        answer: 'No, our ultrasonic technology uses gentle water spray and soft vibrations, making it completely painless and relaxing.',
      },
    ],
  },
  {
    id: 'teeth-whitening',
    title: 'Teeth Whitening',
    shortDesc: 'Laser smile brightening up to 8 shades whiter in a single visit.',
    fullDesc: 'Transform coffee, tea, and tobacco stained teeth into a brilliant white smile. Using gentle LED-activated laser bleaching, Dr. Richa delivers fast, dramatic whitening without sensitivity.',
    iconName: 'Zap',
    category: 'cosmetic',
    duration: '45 - 60 mins',
    estimatedCost: 'Premium Cosmetic Rate',
    benefits: [
      'Up to 8 shades whiter in just 1 hour',
      'Enamel-safe peroxide formulas with desensitizing agents',
      'Long-lasting results up to 2 years',
      'Custom take-home maintenance kit included',
    ],
    procedureSteps: [
      'Shade assessment & lip/gum protection placement',
      'Application of clinical-grade whitening gel',
      'Activation using specialized blue LED laser light',
      'Enamel remineralizing treatment application',
    ],
    faqs: [
      {
        question: 'Will teeth whitening cause tooth sensitivity?',
        answer: 'Dr. Richa uses advanced desensitizing agents so over 95% of patients experience zero discomfort during or after the procedure.',
      },
      {
        question: 'How long do whitening results last?',
        answer: 'With proper care and touch-up gel, your brighter smile lasts anywhere from 1 to 2 years.',
      },
    ],
  },
  {
    id: 'dental-implants',
    title: 'Dental Implants',
    shortDesc: 'Permanent, natural-looking 3D guided titanium tooth replacements.',
    fullDesc: 'The gold standard for missing teeth. Dental implants fuse with your jawbone to provide lifelong strength, restoring full chewing ability, facial structure, and natural smile aesthetics.',
    iconName: 'ShieldCheck',
    category: 'restorative',
    duration: 'Multi-Phase Custom Care',
    estimatedCost: 'Consultation & Flexible Plans',
    benefits: [
      'Looks, feels, and functions like natural teeth',
      'Prevents bone loss and preserves facial youthful shape',
      '3D CBCT guided precision placement',
      'Lifetime durability with proper care',
    ],
    procedureSteps: [
      '3D Digital scan & bone density evaluation',
      'Painless titanium post placement under local anesthesia',
      'Osseointegration healing phase (3-4 months)',
      'Custom porcelain crown attachment',
    ],
    faqs: [
      {
        question: 'Am I a candidate for dental implants?',
        answer: 'Most adults with healthy gums and adequate jawbone density are great candidates. We conduct 3D scans during consultation to confirm.',
      },
      {
        question: 'Are dental implants permanent?',
        answer: 'Yes! Titanium implants integrate with bone and are designed to last a lifetime.',
      },
    ],
  },
  {
    id: 'root-canal',
    title: 'Root Canal Treatment',
    shortDesc: 'Single-visit painless treatment to save infected or painful teeth.',
    fullDesc: 'Say goodbye to severe toothaches. Dr. Richa specializes in micro-endodontics, using flexible rotary instruments to gently clean infected root canals and preserve your natural tooth.',
    iconName: 'Activity',
    category: 'restorative',
    duration: '45 - 60 mins',
    estimatedCost: 'Standard Endodontic Fee',
    benefits: [
      'Instant relief from agonizing toothache',
      'Preserves your natural tooth structure',
      'Single-visit rotary endodontics',
      '98%+ procedure success rate',
    ],
    procedureSteps: [
      'Targeted local numbing for 100% painless comfort',
      'Precision removal of infected nerve pulp',
      'Disinfection & gutta-percha seal placement',
      'Protective ceramic crown placement recommendation',
    ],
    faqs: [
      {
        question: 'Is a root canal painful?',
        answer: 'Modern root canals are no more uncomfortable than getting a standard filling! Local anesthesia ensures total numbness throughout.',
      },
    ],
  },
  {
    id: 'braces-aligners',
    title: 'Braces & Aligners',
    shortDesc: 'Invisible clear aligners & ceramic braces for a straight, confidence smile.',
    fullDesc: 'Correct crooked teeth, gaps, and bite issues with subtle, modern orthodontics. Choose virtually invisible clear aligners or aesthetic ceramic braces tailored by Dr. Richa.',
    iconName: 'Grid',
    category: 'orthodontics',
    duration: '6 - 18 months',
    estimatedCost: 'Flexible Monthly Installments',
    benefits: [
      '3D AI Smile simulation before treatment starts',
      'Removable clear aligners for easy eating & brushing',
      'Aesthetic ceramic & self-ligating metal options',
      'Shorter treatment duration with modern force technology',
    ],
    procedureSteps: [
      'Digital 3D intraoral scan (no messy impression trays)',
      'Custom orthodontic treatment plan & video preview',
      'Aligner set delivery or bracket bonding',
      'Periodic progress checkups every 6-8 weeks',
    ],
    faqs: [
      {
        question: 'Are clear aligners noticeable when wearing them?',
        answer: 'Clear aligners are made from crystal-clear medical polymer and are virtually invisible from normal conversational distance.',
      },
    ],
  },
  {
    id: 'tooth-extraction',
    title: 'Tooth Extraction',
    shortDesc: 'Gentle, minimally invasive wisdom tooth and damaged tooth removal.',
    fullDesc: 'When a tooth is severely damaged or impacted, our traumatic-free extraction technique ensures quick, comfortable removal with minimal swelling and fast recovery.',
    iconName: 'XCircle',
    category: 'surgical',
    duration: '30 - 45 mins',
    estimatedCost: 'Standard Surgical Fee',
    benefits: [
      'Minimally invasive atraumatic extraction',
      'Instant relief for painful wisdom teeth',
      'Platelet-rich fibrin (PRF) option for rapid healing',
      'Comprehensive post-op pain management package',
    ],
    procedureSteps: [
      'Pre-procedure X-ray evaluation',
      'Gentle local anesthesia administration',
      'Aesthetic, gentle tooth removal',
      'Post-extraction care instructions & medication delivery',
    ],
    faqs: [
      {
        question: 'How long is the recovery after wisdom tooth extraction?',
        answer: 'Most patients resume normal activities within 24 to 48 hours following our care instructions.',
      },
    ],
  },
  {
    id: 'smile-makeover',
    title: 'Smile Makeover',
    shortDesc: 'Custom porcelain veneers & aesthetic design tailored to your face.',
    fullDesc: 'Get the Hollywood smile you have always dreamed of. Dr. Richa combines porcelain veneers, gum contouring, and composite bonding to craft a radiant, symmetrical smile that harmonizes with your features.',
    iconName: 'Smile',
    category: 'cosmetic',
    duration: '2 - 3 Visits',
    estimatedCost: 'Custom Smile Design Package',
    benefits: [
      'Customized digital facial proportions matching',
      'Stain-resistant ultra-thin ceramic veneers',
      'Fixes gaps, chips, discoloration & misalignments',
      'Trial smile test drive before permanent bonding',
    ],
    procedureSteps: [
      'Digital Smile Design (DSD) photo/video session',
      '3D mockup trial in your mouth',
      'Minimal prep veneer fabrication',
      'Final bonding & polish for flawless brilliance',
    ],
    faqs: [
      {
        question: 'Do porcelain veneers require grinding down natural teeth?',
        answer: 'Dr. Richa uses ultra-thin micro-veneers requiring minimal or no tooth reduction, keeping your natural teeth healthy.',
      },
    ],
  },
  {
    id: 'pediatric-dentistry',
    title: 'Pediatric Dentistry',
    shortDesc: 'Gentle, friendly, and fun dental care specially designed for children.',
    fullDesc: 'We make visits to the dentist exciting and fear-free for kids! From cavity prevention sealants to gentle fillings, Dr. Richa creates a warm environment where children love caring for their teeth.',
    iconName: 'Heart',
    category: 'preventive',
    duration: '30 mins',
    estimatedCost: 'Kid-Friendly Special Rates',
    benefits: [
      'Playful, anxiety-free clinic environment',
      'Fluoride varnish & protective dental sealants',
      'Habit correction (thumb sucking, tongue thrusting)',
      'Free goodie bag & bravery certificate for every child',
    ],
    procedureSteps: [
      'Friendly introduction & ride in the dentist chair',
      'Fun interactive tooth counting and cleaning',
      'Preventive sealant/fluoride application',
      'Parent oral guidance & positive reinforcement',
    ],
    faqs: [
      {
        question: 'At what age should my child first visit the dentist?',
        answer: 'The American Dental Association recommends a first dental visit by age 1 or when the first tooth appears.',
      },
    ],
  },
  {
    id: 'crowns-bridges',
    title: 'Dental Crowns & Bridges',
    shortDesc: 'High-strength ceramic & Zirconia restorations for damaged or missing teeth.',
    fullDesc: 'Restore broken, cracked, or severely decayed teeth with CAD/CAM precision Zirconia crowns. Metal-free, incredibly durable, and matched perfectly to your natural tooth shade.',
    iconName: 'Crown',
    category: 'restorative',
    duration: '2 Short Visits',
    estimatedCost: 'Insurance Friendly',
    benefits: [
      '100% metal-free biocompatible Zirconia ceramic',
      'Precision CAD/CAM digital scanning (no mess)',
      'Restores full chewing power & natural aesthetic',
      '10-Year structural guarantee',
    ],
    procedureSteps: [
      'Tooth preparation & digital 3D optical scanning',
      'Temporary protective crown placement',
      'Precision custom crown milling',
      'Permanent high-strength bonding',
    ],
    faqs: [
      {
        question: 'How long do ceramic crowns last?',
        answer: 'With good oral hygiene, Zirconia crowns routinely last 15 years or longer.',
      },
    ],
  },
  {
    id: 'emergency-care',
    title: 'Emergency Dental Care',
    shortDesc: 'Same-day urgent treatment for severe pain, broken teeth & dental trauma.',
    fullDesc: 'Dental emergencies cannot wait. Whether you have an unbearable toothache, knocked-out tooth, or cracked restoration, Dr. Richa provides priority same-day emergency treatment.',
    iconName: 'PhoneCall',
    category: 'surgical',
    duration: 'Immediate Priority',
    estimatedCost: 'Priority Urgent Care',
    benefits: [
      'Same-day priority appointment guaranteed',
      'Immediate pain relief & trauma management',
      'Save knocked-out or fractured teeth',
      'Direct emergency call line + WhatsApp support',
    ],
    procedureSteps: [
      'Immediate pain relief medication/numbing',
      'Rapid digital radiography diagnosis',
      'Stabilization & targeted emergency procedure',
      'Follow-up rehabilitation plan',
    ],
    faqs: [
      {
        question: 'What should I do if my tooth is knocked out?',
        answer: 'Handle the tooth by the crown (not the root), gently rinse with milk or saline, store it in milk, and call our emergency line immediately within 60 minutes.',
      },
    ],
  },
];

export const WHY_CHOOSE_US = [
  {
    id: 'experienced-dentist',
    title: 'Experienced Dentist',
    description: 'Dr. Richa brings over 10 years of specialized expertise in aesthetic, endodontic, and implant dentistry with thousands of successful cases.',
    iconName: 'Award',
  },
  {
    id: 'modern-equipment',
    title: 'Modern Equipment',
    description: 'Equipped with 3D CBCT scanners, intraoral digital cameras, painless laser systems, and CAD/CAM digital smile design technology.',
    iconName: 'Cpu',
  },
  {
    id: 'pain-free-treatment',
    title: 'Pain-Free Treatment',
    description: 'Advanced computer-controlled anesthesia delivery and micro-invasive gentle techniques ensure every procedure is completely comfortable.',
    iconName: 'Feather',
  },
  {
    id: 'affordable-pricing',
    title: 'Affordable Pricing',
    description: 'Transparent fees, customized payment plans, insurance assistance, and zero hidden costs so premium care is accessible to everyone.',
    iconName: 'CreditCard',
  },
  {
    id: 'sterilized-clinic',
    title: 'Sterilized Clinic',
    description: 'Strict 6-stage hospital grade Class-B autoclave sterilization and single-use disposable kits guaranteeing 100% hygiene.',
    iconName: 'ShieldAlert',
  },
  {
    id: 'easy-appointment-booking',
    title: 'Easy Appointment Booking',
    description: 'Instant online scheduling, flexible weekend hours, rapid WhatsApp confirmations, and automated gentle appointment reminders.',
    iconName: 'CalendarCheck',
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Priya Sharma',
    role: 'Software Architect',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200&auto=format&fit=crop',
    rating: 5,
    treatment: 'Teeth Whitening & Veneers',
    review: 'Dr. Richa completely changed my smile! I was always self-conscious during client presentations. The laser whitening and porcelain veneers look so natural. The clinic feels like a luxury spa!',
    date: '2 weeks ago',
    verified: true,
  },
  {
    id: '2',
    name: 'Michael Reynolds',
    role: 'Executive Director',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop',
    rating: 5,
    treatment: 'Dental Implant',
    review: 'I was terrified of dental implants after a bad past experience elsewhere. Dr. Richa explained every step using a 3D model. The surgery was completely painless! I can eat anything comfortably again.',
    date: '1 month ago',
    verified: true,
  },
  {
    id: '3',
    name: 'Ananya Mehta',
    role: 'Fashion Designer',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=200&auto=format&fit=crop',
    rating: 5,
    treatment: 'Clear Aligners',
    review: 'Getting clear aligners with Dr. Richa was the best decision! The 3D scan took less than 5 minutes. My teeth were perfectly aligned in just 8 months without anyone noticing I was wearing aligners.',
    date: '3 weeks ago',
    verified: true,
  },
  {
    id: '4',
    name: 'David Chen',
    role: 'University Professor',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&auto=format&fit=crop',
    rating: 5,
    treatment: 'Root Canal & Crown',
    review: 'I had an unbearable severe toothache on a Sunday. Dr. Richa accommodated me immediately for emergency care. The root canal was finished in one sitting with zero pain. Outstanding dentist!',
    date: '2 months ago',
    verified: true,
  },
  {
    id: '5',
    name: 'Sneha & Aarav Kapoor',
    role: 'Parents',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=200&auto=format&fit=crop',
    rating: 5,
    treatment: 'Pediatric Dentistry',
    review: 'My 6-year-old son used to cry at the sight of a dental clinic. Dr. Richa made the entire experience like a fun game. He loved the goodie bag and asks when we can go back! Highly recommend for families.',
    date: '1 month ago',
    verified: true,
  },
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'g1',
    title: 'Hollywood Smile Makeover',
    category: 'transformations',
    imageUrl: 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?q=80&w=800&auto=format&fit=crop',
    beforeUrl: 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?q=80&w=800&auto=format&fit=crop',
    afterUrl: 'https://images.unsplash.com/photo-1606811841689-23dfddce3e95?q=80&w=800&auto=format&fit=crop',
    description: 'Full arch ceramic veneer reconstruction giving a radiant symmetrical smile.',
  },
  {
    id: 'g2',
    title: 'State-of-the-Art Dental Suite',
    category: 'interior',
    imageUrl: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=80&w=800&auto=format&fit=crop',
    description: 'Ergonomic treatment rooms equipped with ceiling entertainment screens and ambient LED lights.',
  },
  {
    id: 'g3',
    title: '3D CBCT Digital Imaging System',
    category: 'equipment',
    imageUrl: 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?q=80&w=800&auto=format&fit=crop',
    description: 'Ultra-low radiation 3D scanning for precise implant planning and nerve tracing.',
  },
  {
    id: 'g4',
    title: 'Laser Teeth Whitening Station',
    category: 'equipment',
    imageUrl: 'https://images.unsplash.com/photo-1598256989800-fe5f95da9787?q=80&w=800&auto=format&fit=crop',
    description: 'Clinical grade cold-laser whitening system delivering fast 8-shade brightening.',
  },
  {
    id: 'g5',
    title: 'Gentle Patient Care & Consultation',
    category: 'care',
    imageUrl: 'https://images.unsplash.com/photo-1629909615184-74f495363b67?q=80&w=800&auto=format&fit=crop',
    description: 'Detailed 3D consultation explaining every step before procedure start.',
  },
  {
    id: 'g6',
    title: 'Invisible Aligner Transformation',
    category: 'transformations',
    imageUrl: 'https://images.unsplash.com/photo-1571772996211-2f02c9727629?q=80&w=800&auto=format&fit=crop',
    beforeUrl: 'https://images.unsplash.com/photo-1598256989800-fe5f95da9787?q=80&w=800&auto=format&fit=crop',
    afterUrl: 'https://images.unsplash.com/photo-1571772996211-2f02c9727629?q=80&w=800&auto=format&fit=crop',
    description: 'Overbite & crowding correction achieved in 10 months with clear aligners.',
  },
];

export const FAQS = [
  {
    q: 'What should I bring to my first appointment?',
    a: 'Please bring a photo ID, insurance card (if applicable), and any previous dental X-rays taken in the last 12 months.',
  },
  {
    q: 'Do you accept dental insurance or offer payment plans?',
    a: 'Yes! We accept all major dental PPO insurance plans and offer 0% interest monthly payment installments for major treatments like implants and aligners.',
  },
  {
    q: 'How does Dr. Richa ensure painless treatment?',
    a: 'We use computer-guided local anesthesia delivery, soothing numbing gels before injections, and relaxing clinic ambience. You feel no pain during procedures.',
  },
  {
    q: 'What sterilization protocols does the clinic follow?',
    a: 'We strictly follow international CDC & OSHA guidelines with Class-B autoclave heat sterilization, disposable barrier wraps, and air purification systems in every room.',
  },
];
